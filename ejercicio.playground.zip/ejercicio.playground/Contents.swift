//: Playground - noun: a place where people can play

import UIKit

class Student{
    var name : String?
    var surname : String?
    var age : Int?
    var phone : String?
    var address : String?
    var email : String?

    convenience init (name : String? = nil, surname : String? = nil, age: Int?, address : String? = nil, email : String? = nil){
        self.init()
        self.name = name
        self.surname = surname
        self.age = age
        self.address = address
        self.email = email
    }
}
class Teacher{
    var name : String?
    var surname : String?
    var age : Int?
    var type : String?
    var email : String?
    
    convenience init (name : String? = nil, surname : String? = nil, age: Int? = nil, type : String? = nil, email : String? = nil){
        self.init()
        self.name = name
        self.surname = surname
        self.age = age
        self.type = type
        self.email = email
    }
}
class Subject{
    var name : String?
    var year : Int?
    var teachers : [Teacher]?
    var students : [Student]?
    
    convenience init (name : String? = nil, year : Int? = nil, teachers : [Teacher]? = nil, students : [Student]? = nil ){
        self.init()
        self.name = name
        self.students = students
        self.teachers = teachers
    }
}

let students = [Student(name: "David",
                        age: 9,
                        email: "dadaadaol@adsasd.com"),
                Student(name: "Diego",
                        age: 14,
                        email: "ddddddol@adsasd.com"),
                Student(name: "Mario",
                        age: 16,
                        email: "aaaaol@adsasd.com"),
                Student(name: "Javier",
                        age: 20,
                        email: "ddddol@adsasd.com"),
                Student(name: "Oliver",
                        age: 5,
                        email: "wwwwol@adsasd.com"),
                Student(name: "Carlos",
                        age: 6,
                        email: "aaaol@adsasd.com"),
                Student(name: "Alvaro",
                        age: 5,
                        email: "olddd@adsasd.com"),
                Student(name: "Minguez",
                        age: 3,
                        email: "dsadasol@adsasd.com")]

let teachers = [Teacher(name: "John",
                        type: "interno",
                        email: "jjjhhhholasas@adsasd.com"),
                Teacher(name: "James",
                        type: "interno",
                        email: "jjjjol@adsasd.com"),
                Teacher(name: "Cris",
                        type: "externo",
                        email: "cccccol@adsasd.com"),
                Teacher(name: "Michel",
                        type: "externo",
                        email: "mmmmol@adsasd.com"),
                Teacher(name: "Rust",
                        type: "interno",
                        email: "rrrrol@adsasd.com"),
                Teacher(name: "Martin",
                        type: "interno",
                        email: "mmmmol@adsasd.com"),
                Teacher(name: "Wendell",
                        type: "externo",
                        email: "wwwwol@adsasd.com"),
                Teacher(name: "Elli",
                        type: "interno",
                        email: "eeeol@adsasd.com")]
let subjects = [Subject(name: "iOS",
                        year: 2019,
                        teachers: teachers.filter{ $0.name?.contains("u") ?? false},
                        students: students.filter{ $0.name?.contains("a") ?? false}),
                Subject(name: "Java",
                        year: 2019,
                        teachers: teachers.filter{ $0.name?.contains("o") ?? false},
                        students: students.filter{ $0.name?.contains("e") ?? false}),
                Subject(name: "Python",
                        year: 2019,
                        teachers: teachers.filter{ $0.name?.contains("u") ?? false},
                        students: students.filter{ $0.name?.contains("u") ?? false}),
                Subject(name: "C",
                        year: 2019,
                        teachers: teachers.filter{ $0.name?.contains("u") ?? false},
                        students: students.filter{ $0.name?.contains("u") ?? false}),
                Subject(name: "Android",
                        year: 2019,
                        teachers: teachers.filter{ $0.name?.contains("u") ?? false},
                        students: students.filter{ $0.name?.contains("u") ?? false}),
]
students.forEach { student in
    guard let studentName = student.name else {
        return
    }
    let subject = subjects.filter{$0.students?.contains( where: {subject in
        guard let StudentSubjectName = subject.name else{
        return false }
        return StudentSubjectName.compare(studentName) == .orderedSame
    }) ?? false }
    print(studentName)
    print (subject.count)
    print(subject.compactMap {$0.name})
    
}
students.forEach { student in
    guard let studentName = student.name else {
        return
    }
    let subject = subjects.filter{$0.students?.contains( where: {subject in
        guard let StudentSubjectName = subject.name else{
            return false }
        return StudentSubjectName.compare(studentName) == .orderedSame
    }) ?? false }
    if(subject.count>1){
            print("\(studentName) esta en mas de una asignatura")
    }

    
    
}





